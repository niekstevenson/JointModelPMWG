adapt.c.dmc <- function(startValues, learningRates, feedback, learningRule='SARSA',
                        learningRatesNeg=NULL, riskStartValues=NULL, riskLearningRates=NULL) {
  nTrials <- nrow(feedback)
  nAdapt <- ncol(feedback)

  # declare output array
  adaptedValues <- predictionErrors <- matrix(nrow=nTrials, ncol=nAdapt)

  if(!is.null(learningRatesNeg)) {
    out = .C('adaptSARSA2LR',
             nTrials=nTrials,
             nChoices=nAdapt,
             values=as.double(startValues),
             adaptedValues=as.double(adaptedValues),
             predictionErrors=as.double(predictionErrors),
             outcomes=as.double(feedback),
             learningRatesPos=as.double(learningRates),
             learningRatesNeg=as.double(learningRatesNeg),
             NAOK=TRUE)
  } else {
    if(learningRule=='SARSA') {
      out = .C('adaptSARSA',
               nTrials=nTrials,
               nChoices=nAdapt,
               values=as.double(startValues),
               adaptedValues=as.double(adaptedValues),
               predictionErrors=as.double(predictionErrors),
               outcomes=as.double(feedback),
               learningRates=as.double(learningRates),
               NAOK=TRUE)
    } else if(learningRule == 'SARSAvarLR') {
      out = .C('adaptSARSAvarLR',
               nTrials=nTrials,
               nChoices=nAdapt,
               values=as.double(startValues),
               adaptedValues=as.double(adaptedValues),
               predictionErrors=as.double(predictionErrors),
               outcomes=as.double(feedback),
               learningRates=as.double(learningRates),
               NAOK=TRUE)
    } else if(learningRule == 'SARSARisk') {
      adaptedRiskValues <- riskPredictionErrors <- matrix(nrow=nTrials, ncol=nAdapt)

      out = .C('adaptSARSARisk',
               nTrials=nTrials,
               nChoices=nAdapt,
               values=as.double(startValues),
               adaptedValues=as.double(adaptedValues),
               riskValues=as.double(riskStartValues),
               adaptedRiskValues=as.double(adaptedRiskValues),
               predictionErrors=as.double(predictionErrors),
               riskPredictionErrors=as.double(riskPredictionErrors),
               outcomes=as.double(feedback),
               learningRates=as.double(learningRates),
               riskLearningRates=as.double(riskLearningRates),
               NAOK=TRUE)
    } else if(learningRule == 'SARSARisk2') {
      adaptedRiskValues <- riskPredictionErrors <- matrix(nrow=nTrials, ncol=nAdapt)

      out = .C('adaptSARSARisk2',
               nTrials=nTrials,
               nChoices=nAdapt,
               values=as.double(startValues),
               adaptedValues=as.double(adaptedValues),
               riskValues=as.double(riskStartValues),
               adaptedRiskValues=as.double(adaptedRiskValues),
               predictionErrors=as.double(predictionErrors),
               riskPredictionErrors=as.double(riskPredictionErrors),
               outcomes=as.double(feedback),
               learningRates=as.double(learningRates),
               riskLearningRates=as.double(riskLearningRates),
               NAOK=TRUE)
    } else if(learningRule == 'SARSARiskNiek2') {
      adaptedRiskValues <- riskPredictionErrors <- matrix(nrow=nTrials, ncol=nAdapt)

      out = .C('adaptSARSARiskNiek_CentralTendency',
               nTrials=nTrials,
               nChoices=nAdapt,
               values=as.double(startValues),
               adaptedValues=as.double(adaptedValues),
               riskValues=as.double(riskStartValues),
               adaptedRiskValues=as.double(adaptedRiskValues),
               predictionErrors=as.double(predictionErrors),
               riskPredictionErrors=as.double(riskPredictionErrors),
               outcomes=as.double(feedback),
               learningRates=as.double(learningRates),
               riskLearningRates=as.double(riskLearningRates),
               NAOK=TRUE)
    }

  }

  adaptedValues <- matrix(out$adaptedValues, nrow=nTrials, ncol=nAdapt)
  predictionErrors <- matrix(out$predictionErrors, nrow=nTrials, ncol=nAdapt)

  if(is.null(riskLearningRates)) {
    list(adaptedValues=adaptedValues, predictionErrors=predictionErrors)
  } else {
    adaptedRiskValues <- matrix(out$adaptedRiskValues, nrow=nTrials, ncol=nAdapt)
    riskPredictionErrors <- matrix(out$riskPredictionErrors, nrow=nTrials, ncol=nAdapt)
    list(adaptedValues=adaptedValues, predictionErrors=predictionErrors,
         adaptedRiskValues=adaptedRiskValues, riskPredictionErrors=riskPredictionErrors)
  }
}

#
# adapt.r.test <- function(startValues, learningRates, feedback, learningRule='SARSA',
#                          learningRatesNeg=NULL, riskStartValues=NULL, riskLearningRates=NULL) {
#   nTrials <- nrow(feedback)
#   nAdapt <- ncol(feedback)
#
#   # declare output array
#   adaptedValues <- predictionErrors <- matrix(nrow=nTrials, ncol=nAdapt)
#
#   if(learningRule == 'SARSARisk') {
#     adaptedRiskValues <- riskPredictionErrors <- matrix(nrow=nTrials, ncol=nAdapt)
#     riskValues <- riskStartValues
#   }
#
#   values <- startValues
#   # Update all values (can we vectorize this? Hopefully)
#   for(trial in 1:nTrials) {
#     c_ = which(!is.na(feedback[trial,])) #choice[trial] # c_ = choice
#     o_ = feedback[trial,c_] # o_ = outcome
#
#     # Keep track of current value, used later for drift rates
#     adaptedValues[trial, c_] = values[c_]
#     adaptedValues[trial, -c_] = values[-c_]
#
#     if(learningRule == 'SARSA' | learningRule == 'SARSAvarLR' | learningRule == 'SARSARisk') {
#       predicted <- values[c_]
#       if(learningRule == 'SARSARisk') {
#         adaptedRiskValues[trial, c_] = riskValues[c_]
#         adaptedRiskValues[trial, -c_] = riskValues[-c_]
#       }
#     } else if(learningRule == 'Qlearning')  {
#       predicted <- max(values)
#     }
#     # calculate PE
#     dv = o_-predicted  # prediction error = outcome (reward) - predicted value
#     predictionErrors[trial,c_] <- dv  # keep track of this
#
#     if(!is.null(learningRatesNeg)) {
#       LR = ifelse(dv>0, learningRates[trial,c_], learningRatesNeg[trial,c_])
#     } else if(learningRule == 'SARSAvarLR') {
#       LR = learningRates[trial,c_] * (predicted*(1-predicted))
#     } else if (learningRule == 'SARSA') {
#       LR = learningRates[trial,c_]
#     } else if(learningRule == 'SARSARisk') {
#       LR = learningRates[trial,c_]
#       riskLR = riskLearningRates[trial, c_]
#       # update risk
#       riskPE <- dv^2 - riskValues[c_]
#       riskValues[c_] = riskValues[c_]+riskLR*riskPE
#       riskPredictionErrors[trial,c_] = riskPE
#       dv <- dv /sqrt(riskValues[c_])  # scale PE
#     }
#     values[c_] = values[c_] + LR*dv
#
#     # # update values
#     # if(!is.null(learningRatesNeg)) {
#     #   values[c_] = values[c_] + ifelse(dv>0, learningRates[trial,c_], learningRatesNeg[trial,c_])*dv
#     # } else {
#     #   if(learningRule == 'SARSAvarLR') {
#     #     LR
#     #   }
#     #   values[c_] = values[c_] + learningRates[trial,c_]*dv
#     # }
#   }
#   if(learningRule == 'SARSARisk') {
#     return(list(adaptedValues=adaptedValues, predictionErrors=predictionErrors,
#            adaptedRiskValues=adaptedRiskValues, riskPredictionErrors=riskPredictionErrors))
#   } else {
#     return(list(adaptedValues=adaptedValues, predictionErrors=predictionErrors))
#   }
# }
# # #
# # #
# library(dmcAdapt)
# # #
# # nTrials <- 100
# # notChosen <- sample(c(1, 2), size=nTrials, replace=TRUE)
# # eta1 <- .3
# # eta2 <- .4
# # startValues <- c(.5, .5)
# # feedback <- matrix(rnorm(nTrials*2, 5, 3), nrow=nTrials)
# # feedback[cbind(1:nTrials, as.numeric(notChosen))] <- NA
# # choice <- ifelse(notChosen==1, 2, 1)
# # #
# # tmpSarsaC = adapt.c.dmc(feedback=feedback, startValues=startValues, matrix(eta1, nrow=nTrials, ncol=2), learningRule='SARSA')
# # tmpSarsaR = adapt.r.test(feedback=feedback, startValues=startValues, matrix(eta1, nrow=nTrials, ncol=2), learningRule='SARSA')
# #
# # tmpSarsaC$adaptedValues == tmpSarsaR$adaptedValues
# #
# #
# ## negative learning rates?
# posLR <- matrix(eta1, nrow=nTrials, ncol=2)
# negLR <- matrix(eta2, nrow=nTrials, ncol=2)
# tmpSarsaC = adapt.c.dmc(feedback=feedback, startValues=startValues, posLR, learningRule='SARSA', negLR)
# tmpSarsaR = adapt.r.test(feedback=feedback, startValues=startValues, posLR, learningRule='SARSA', negLR)
#
#
# ## variable learning rates?
# tmpSarsaC = adapt.c.dmc(feedback=feedback, startValues=startValues, matrix(eta1, nrow=nTrials, ncol=2), learningRule='SARSAvarLR')
# tmpSarsaR = adapt.r.test(feedback=feedback, startValues=startValues, matrix(eta1, nrow=nTrials, ncol=2), learningRule='SARSAvarLR')
#
# tmpSarsaC$adaptedValues == tmpSarsaR$adaptedValues
#
#
# ## Risk learning?
# riskStartValues <- c(1,1)
# tmpSarsaRiskC = adapt.c.dmc(feedback=feedback, startValues=startValues, matrix(eta1, nrow=nTrials, ncol=2),
#                             learningRule='SARSARisk', riskStartValues=riskStartValues, riskLearningRates = matrix(eta1, nrow=nTrials, ncol=2))
# tmpSarsaRiskR = adapt.r.test(feedback=feedback, startValues=startValues, matrix(eta1, nrow=nTrials, ncol=2),
#                              learningRule='SARSARisk', riskStartValues=riskStartValues, riskLearningRates = matrix(eta1, nrow=nTrials, ncol=2))
# tmpSarsaRiskC$adaptedValues == tmpSarsaRiskR$adaptedValues
# tmpSarsaRiskC$adaptedRiskValues == tmpSarsaRiskR$adaptedRiskValues
# tmpSarsaRiskC$riskPredictionErrors == tmpSarsaRiskR$riskPredictionErrors
