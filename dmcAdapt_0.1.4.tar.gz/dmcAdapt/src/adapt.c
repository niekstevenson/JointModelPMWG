#include <math.h>
#include <Rmath.h>
#include <stdlib.h>
#include <R.h>
#include <stdbool.h>
#include <stdio.h>

// SARSA = State-Action-Response-State-action, default learning rule (Rescorla-Wagner)
void adaptSARSA(int *nTrials,
                int *nChoices,
                double *values,
                double *adaptedValues, // of length ntrials*n_pairs
                double *predictionErrors,
                double *outcome,
                double *learningRates) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)

  // declare some variables
  //  double updateValue;
  double this_lr;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.

  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE

    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values

      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        this_lr = learningRates[mat_idx];
        //        printf("Outcome is: %.3f, this is NOT NA!\n", outcome[mat_idx]);
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE

        // Do we update with eta1 or eta2?
        //        updateValue = dv[ch] > 0 ? this_eta1 : this_eta2;  // Ternary expression  (if-else in a one-liner)

        values[ch] = values[ch] + this_lr*dv[ch];  // Update value
      }
    }
  }
}

// Dual learning rates
void adaptSARSA2LR(int *nTrials,
                   int *nChoices,
                   double *values,
                   double *adaptedValues, // of length ntrials*n_pairs
                   double *predictionErrors,
                   double *outcome,
                   double *learningRatesPos,
                   double *learningRatesNeg) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)

  // declare some variables
  double updateValue;
  double this_lr;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.

  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE

    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values

      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        //        this_lr = learningRates[mat_idx];
        //        printf("Outcome is: %.3f, this is NOT NA!\n", outcome[mat_idx]);
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE

        // Do we update with eta1 or eta2?
        this_lr = dv[ch] > 0 ? learningRatesPos[mat_idx] : learningRatesNeg[mat_idx];  // Ternary expression  (if-else in a one-liner)

        values[ch] = values[ch] + this_lr*dv[ch];  // Update value
      }
    }
  }
}



void adaptSARSARisk(int *nTrials,
                     int *nChoices,
                     double *values,
                     double *adaptedValues, // of length ntrials*n_pairs
                     double *riskValues,
                     double *adaptedRiskValues,
                     double *predictionErrors,
                     double *riskPredictionErrors,
                     double *outcome,
                     double *learningRates,
                     double *riskLearningRates) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)

  // declare some variables
  //  double updateValue;
  double this_lr;
  double this_risk_lr;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.
  static double riskdv[128] = {0};

  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE

    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values
      adaptedRiskValues[mat_idx] = riskValues[ch]; // offload risk

      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        this_lr = learningRates[mat_idx];
        this_risk_lr = learningRates[mat_idx];

        // Compute reward prediction error
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE

        // Compute risk prediction error
        riskdv[ch] = dv[ch]*dv[ch] - riskValues[ch];
        riskPredictionErrors[mat_idx] = riskdv[ch];

        // Update risk
        riskValues[ch] = riskValues[ch] + this_risk_lr * riskdv[ch];

        // Update reward expectation, scale PE by risk
        values[ch] = values[ch] + this_lr*(dv[ch] / sqrt(riskValues[ch]));  // Update value

        // offload actual learning rate
//        learningRates[mat_idx] = this_variance*this_lr;
      }
    }
  }
}

void adaptSARSARisk2(int *nTrials,
                    int *nChoices,
                    double *values,
                    double *adaptedValues, // of length ntrials*n_pairs
                    double *riskValues,
                    double *adaptedRiskValues,
                    double *predictionErrors,
                    double *riskPredictionErrors,
                    double *outcome,
                    double *learningRates,
                    double *riskLearningRates) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)

  // declare some variables
  //  double updateValue;
  double this_lr;
  double this_risk_lr;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.
  static double riskdv[128] = {0};

  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE

    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values
      adaptedRiskValues[mat_idx] = riskValues[ch]; // offload risk

      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        this_lr = learningRates[mat_idx];
        this_risk_lr = learningRates[mat_idx];

        // Compute reward prediction error
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE

        // Compute risk prediction error
        riskdv[ch] = dv[ch]*dv[ch] - riskValues[ch];
        riskPredictionErrors[mat_idx] = riskdv[ch];

        // Update risk
        riskValues[ch] = riskValues[ch] + this_risk_lr * riskdv[ch];

        // Update reward expectation, scale PE by risk (multiply for 0<risk<1)
        values[ch] = values[ch] + this_lr*dv[ch] * riskValues[ch];  // Update value

        // offload actual learning rate
        //        learningRates[mat_idx] = this_variance*this_lr;
      }
    }
  }
}

void adaptSARSARiskNiek(int *nTrials,
                        int *nChoices,
                        double *values,
                        double *adaptedValues, // of length ntrials*n_pairs
                        double *riskValues,
                        double *adaptedRiskValues,
                        double *predictionErrors,
                        double *riskPredictionErrors,
                        double *outcome,
                        double *learningRates,
                        double *riskLearningRates) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)
  
  // declare some variables
  //  double updateValue;
  double this_lr;
  double this_risk_lr;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.
  static double riskdv[128] = {0};
  
  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE
    
    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values
      adaptedRiskValues[mat_idx] = riskValues[ch]; // offload risk
      
      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        this_lr = learningRates[mat_idx];
        this_risk_lr = learningRates[mat_idx];
        
        // Compute reward prediction error
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE
        
        // Compute risk prediction error
        riskdv[ch] = dv[ch]*dv[ch] - riskValues[ch];
        riskPredictionErrors[mat_idx] = riskdv[ch];
        
        // Update risk
        riskValues[ch] = riskValues[ch] + this_risk_lr * riskdv[ch];
        
        // Update reward expectation, scale PE by risk (multiply for 0<risk<1)
        values[ch] = values[ch] + this_lr*dv[ch] / riskValues[ch];  // Update value
        
        // offload actual learning rate
        //        learningRates[mat_idx] = this_variance*this_lr;
      }
    }
  }
}

void adaptSARSARiskNiek_CentralTendency(int *nTrials,
                                        int *nChoices,
                                        double *values,
                                        double *adaptedValues, // of length ntrials*n_pairs
                                        double *riskValues,
                                        double *adaptedRiskValues,
                                        double *predictionErrors,
                                        double *riskPredictionErrors,
                                        double *outcome,
                                        double *learningRates,
                                        double *riskLearningRates) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)
  
  // declare some variables
  //  double updateValue;
  double this_lr;
  double this_risk_lr;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.
  static double riskdv[128] = {0};
  
  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE
    
    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values
      adaptedRiskValues[mat_idx] = riskValues[ch]; // offload risk
      
      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        this_lr = learningRates[mat_idx];
        this_risk_lr = learningRates[mat_idx];
        
        // Compute reward prediction error
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE
        
        // Compute risk prediction error
        riskdv[ch] = dv[ch] - riskValues[ch];
        riskPredictionErrors[mat_idx] = riskdv[ch];
        
        // Update risk
        riskValues[ch] = riskValues[ch] + this_risk_lr * riskdv[ch];
        
        // Update reward expectation, scale PE by risk (multiply for 0<risk<1)
        values[ch] = values[ch] + this_lr*dv[ch] * sqrt(riskValues[ch]*riskValues[ch]);  // Update value
        
        // offload actual learning rate
        //        learningRates[mat_idx] = this_variance*this_lr;
      }
    }
  }
}


void adaptSARSAvarRL(int *nTrials,
                    int *nChoices,
                    double *values,
                    double *adaptedValues, // of length ntrials*n_pairs
                    double *predictionErrors,
                    double *outcome,
                    double *learningRates) {
  // nTrials: number of trials
  // nChoices: total number of choice options. For example, 3 pairs of 2 stimuli = 6 choices
  // values: initial value of each choice option (length nChoices)
  // VV: output for trial-by-trial values of each choice option. In R, a matrix of size (nTrials, nChoices); here in C, an array of length (nTrials*nChoices)
  // PE: output for trial-by-trial prediction errors for each choie option. Identical size as VV
  // outcome: (nTrials, nChoices): trial by trial outcomes per choice option. NA is no output.
  // eta1, eta2: floats with the learning rates (positive and negative, respectively)

  // declare some variables
  //  double updateValue;
  double this_lr;
  double this_variance;
  int mat_idx = 0;
  int nt = *nTrials;
  int nc = *nChoices;
  static double dv[128] = {0};   // WARNING: MAXIMUM NUMBER OF CHOICES IS FIXED HERE TO 128. Anything more will crash.

  // Loop over trials i
  for(unsigned int i = 0; i < nt; i++) {
    //    printf("Trial N: %d\n", i);
    //    this_eta1 = eta1[i];  // trialwise learning rate for positive PE
    //    this_eta2 = eta2[i];  // trialwise learning rate for negative PE

    // Loop over choice alternatives
    for(unsigned int ch = 0; ch < nc; ch++) {
      //      printf("Choice option: %d\n", ch);
      mat_idx = nt*ch+i;  // Where in the VV-matrix and outcome-matrix are we?
      adaptedValues[mat_idx] = values[ch]; // Offload current values

      // If the outcome for this choice was not NA, update (note that o_ == o_ returns FALSE if o_ is NA)
      if(outcome[mat_idx] == outcome[mat_idx]) {
        this_lr = learningRates[mat_idx];
        this_variance = values[ch] * (1-values[ch]);  // ASSUMES BINOMIAL DISTRIBUTION!
        //        printf("Outcome is: %.3f, this is NOT NA!\n", outcome[mat_idx]);
        dv[ch] = outcome[mat_idx] - values[ch];  // prediction error dv = outcome choice - value of choice
        predictionErrors[mat_idx] = dv[ch];  // offload PE

        // Do we update with eta1 or eta2?
        //        updateValue = dv[ch] > 0 ? this_eta1 : this_eta2;  // Ternary expression  (if-else in a one-liner)

        values[ch] = values[ch] + this_variance*this_lr*dv[ch];  // Update value

        // offload actual learning rate
        learningRates[mat_idx] = this_variance*this_lr;
      }
    }
  }
}
